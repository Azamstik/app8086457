self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f4cd712591436824795fecb30e3cbcd5",
    "url": "./index.html"
  },
  {
    "revision": "1052476bd4e2a72f8fae",
    "url": "./static/css/2.12c547fe.chunk.css"
  },
  {
    "revision": "6f02efbd6f74e18e37e2",
    "url": "./static/css/main.4e2c9225.chunk.css"
  },
  {
    "revision": "1052476bd4e2a72f8fae",
    "url": "./static/js/2.8e39cf80.chunk.js"
  },
  {
    "revision": "6f02efbd6f74e18e37e2",
    "url": "./static/js/main.59481290.chunk.js"
  },
  {
    "revision": "1b437403f16bd71edadb",
    "url": "./static/js/runtime-main.9d7e574d.js"
  },
  {
    "revision": "e64fc9d01f0600a9faf13ce71c15d0ed",
    "url": "./static/media/FontsFree-Net-SF-Pro-Rounded-Bold.e64fc9d0.ttf"
  },
  {
    "revision": "907212050e2a59fbb0aa4cb95b7ca4c0",
    "url": "./static/media/FontsFree-Net-SF-Pro-Rounded-Semibold.90721205.ttf"
  },
  {
    "revision": "5120d3df018abafe6f50a819eab3f330",
    "url": "./static/media/Ghost.5120d3df.svg"
  },
  {
    "revision": "d616a75646571c5d0e0b26289c801519",
    "url": "./static/media/Layer-0.d616a756.png"
  },
  {
    "revision": "9edc0ec286ed0b1eecc2bbadec452358",
    "url": "./static/media/Layer-1.9edc0ec2.png"
  },
  {
    "revision": "9e8cdb8c98327a3f184c4172c24ce6c6",
    "url": "./static/media/Layer-2.9e8cdb8c.png"
  },
  {
    "revision": "843fedd0c8698cfa871eb8040c8c3806",
    "url": "./static/media/Layer-3.843fedd0.png"
  },
  {
    "revision": "f7974e967360170e6bc4096d2241b46f",
    "url": "./static/media/Layer-4.f7974e96.png"
  },
  {
    "revision": "73df55bb10d5ad768a1f376066091cda",
    "url": "./static/media/Layer-5.73df55bb.png"
  },
  {
    "revision": "2640802b08e8f37e557305e1c116ccd4",
    "url": "./static/media/Manrope.2640802b.ttf"
  },
  {
    "revision": "ee6539921d713482b8ccd4d0d23961bb",
    "url": "./static/media/Montserrat-Regular.ee653992.ttf"
  },
  {
    "revision": "c641dbee1d75892e4d88bdc31560c91b",
    "url": "./static/media/Montserrat-SemiBold.c641dbee.ttf"
  },
  {
    "revision": "dc670acd30e72280b8df592924b7aba9",
    "url": "./static/media/Noob.dc670acd.svg"
  },
  {
    "revision": "2b93e8e975cd6d488fe0e635541728f9",
    "url": "./static/media/ProximaNova-Bold.2b93e8e9.ttf"
  },
  {
    "revision": "644563f48ab5fe8e9082b64b2729b068",
    "url": "./static/media/SF-Pro-Display-Bold.644563f4.otf"
  },
  {
    "revision": "51fd7406327f2b1dbc8e708e6a9da9a5",
    "url": "./static/media/SF-Pro-Display-Medium.51fd7406.otf"
  },
  {
    "revision": "aaeac71d99a345145a126a8c9dd2615f",
    "url": "./static/media/SF-Pro-Display-Regular.aaeac71d.otf"
  },
  {
    "revision": "e6ef4ea3cf5b1b533a85a5591534e3e4",
    "url": "./static/media/SF-Pro-Display-Semibold.e6ef4ea3.otf"
  },
  {
    "revision": "400bd9f855cefe6a13b02eb55a31d511",
    "url": "./static/media/SF-Pro-Rounded-Regular.400bd9f8.ttf"
  },
  {
    "revision": "85bd46c1cff02c1d8360cc714b8298fa",
    "url": "./static/media/SF-Pro-Text-Regular.85bd46c1.ttf"
  },
  {
    "revision": "d4550c5e326a628ac8ef82e9f2703484",
    "url": "./static/media/SFUIDisplay-Regular.d4550c5e.otf"
  },
  {
    "revision": "888e0f3f1d925d57beaf9cc4a7b80dbc",
    "url": "./static/media/SFUIText-Regular.888e0f3f.otf"
  },
  {
    "revision": "c7c4799ed1182d24a48397cf98074b7f",
    "url": "./static/media/Stupid-Head.c7c4799e.ttf"
  },
  {
    "revision": "fc6fbc1addf37a7f957715e41b20291d",
    "url": "./static/media/TTCommons-Regular.fc6fbc1a.ttf"
  },
  {
    "revision": "d9521fb6878e132c215281e9494e232a",
    "url": "./static/media/WC-Mano-Negra-Bta.d9521fb6.otf"
  },
  {
    "revision": "4c524f19e7e2a8c19618144cd5bd25b3",
    "url": "./static/media/background.4c524f19.png"
  },
  {
    "revision": "77233fe5ac47c256bb84afe0f48e43e8",
    "url": "./static/media/background.77233fe5.png"
  },
  {
    "revision": "d081461d8e1e95329f0c466db7a16ba4",
    "url": "./static/media/monkey.d081461d.png"
  },
  {
    "revision": "2be0be7ed1e941c563cc0c6a3644aca5",
    "url": "./static/media/online.2be0be7e.png"
  },
  {
    "revision": "dbead3484bac4c7bdf3743f7826bcd3b",
    "url": "./static/media/share_10.dbead348.png"
  },
  {
    "revision": "7b1ee29124ee692a138d840e02d027ba",
    "url": "./static/media/share_7.7b1ee291.png"
  },
  {
    "revision": "7cdf34c53a6ef98183cae08aa3be5dfc",
    "url": "./static/media/share_8.7cdf34c5.png"
  },
  {
    "revision": "ba6ad52579408e32f621a0599abafff2",
    "url": "./static/media/share_9.ba6ad525.png"
  }
]);